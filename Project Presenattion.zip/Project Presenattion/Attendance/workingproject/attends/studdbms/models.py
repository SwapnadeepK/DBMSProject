# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Attendence(models.Model):
    a_id = models.CharField(db_column='A_id', primary_key=True, max_length=8)
    adate = models.DateField(db_column='Adate', blank=False, null=True)  # Field name made lowercase.
    period = models.TimeField(db_column='Period', blank=False, null=True)
    usn = models.CharField(db_column='USN', max_length=100, blank=False, null=True)  # Field name made lowercase.
    scode = models.CharField(db_column='Scode', max_length=100, blank=False, null=True)  # Field name made lowercase.
    status = models.CharField(db_column='Status', max_length=1, blank=False, null=True)

    def __str__(self):
        return self.usn
    
    class Meta:
        db_table = 'attendence'


class Department(models.Model):
    dept_id = models.CharField(db_column='Dept_id', primary_key=True, max_length=8)  # Field name made lowercase.
    dept_name = models.CharField(db_column='Dept_name', max_length=20, blank=False, null='True')  # Field name made lowercase.

    def __str__(self):
        return self.dept_id

    class Meta:
        db_table = 'department'


class Parents(models.Model):
    p_id = models.IntegerField(db_column='P_id', primary_key=True, blank=False)
    pname = models.CharField(db_column='Pname', max_length=20, blank=False, null=True)  # Field name made lowercase.
    stud_usn = models.CharField(db_column='Stud_usn', max_length=20, blank=False, null=True)  # Field name made lowercase.
    address = models.CharField(db_column='Address', max_length=300, blank=False, null=True)  # Field name made lowercase.
    phone = models.BigIntegerField(db_column='Phone', blank=False, null=True)

    def __str__(self):
        return self.pname

    class Meta:
        db_table = 'parents'


class StaffDetails(models.Model):
    staff_id = models.CharField(db_column='Staff_id', primary_key=True, max_length=10, blank=False)
    fn = models.CharField(db_column='Fn', max_length=15, blank=False, null=True)  # Field name made lowercase.
    ln = models.CharField(db_column='Ln', max_length=15, blank=False, null=True)  # Field name made lowercase.
    password = models.CharField(db_column='Password', max_length=10, blank=False, null=True)
    qualifications = models.CharField(db_column='Qualifications', max_length=20, blank=False, null=True)  # Field name made lowercase.
    dept = models.CharField(db_column='Dept', max_length=20, blank=False, null=True)  # Field name made lowercase.

    def __str__(self):
        return self.fn
    
    class Meta:
        db_table = 'staff_details'


class Students(models.Model):
    stud_id = models.CharField(db_column='Stud_id', primary_key=True, max_length=10, blank=False)
    usn = models.CharField(db_column='USN', max_length=10, blank=False, null=True)  # Field name made lowercase.
    fn = models.CharField(db_column='Fn', max_length=15, blank=False, null=True)  # Field name made lowercase.
    ln = models.CharField(db_column='Ln', max_length=15, blank=False, null=True)  # Field name made lowercase.
    dept = models.CharField(db_column='Dept', blank=False, max_length=20, null=True)  # Field name made lowercase.
    gender = models.CharField(db_column='Gender', max_length=6, blank=False, null=True)
    sem = models.IntegerField(db_column='Sem', blank=False, null=True)
    dob = models.DateField(db_column='DOB', blank=False, null=True)  # Field name made lowercase.
    phone = models.IntegerField(db_column='Phone', blank=False, null=True)
    sec = models.CharField(db_column='Sec', max_length=1, blank=False, null=True)

    class Meta:
        db_table = 'students'
    
    def __str__(self):
        return self.usn


class Subjects(models.Model):
    sub_id = models.CharField(db_column='Sub_id', primary_key=True, max_length=10, blank=False)
    scode = models.CharField(db_column='Scode', max_length=8, blank=False, null=True)  # Field name made lowercase.
    sname = models.CharField(db_column='Sname', max_length=20, blank=False, null=True)
    sem = models.IntegerField(db_column='Sem', blank=False, null=True)
    dept = models.CharField(db_column='Dept', max_length=20, blank=False, null=True)  # Field name made lowercase.

    def __str__(self):
        return self.sname

    class Meta:
        db_table = 'subjects'


class Timings(models.Model):
    t_id = models.CharField(db_column='T_id', primary_key=True, max_length=8)
    pno = models.CharField(db_column='Pno', max_length=1, blank=False, null=True)  # Field name made lowercase.
    timings = models.TimeField(db_column='Timings', blank=False, null=True)

    def __str__(self):
        return self.pno

    class Meta:
        db_table = 'timings'
