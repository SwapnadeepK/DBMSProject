from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from .models import *
from .forms import *

# Create your views here.

def index(request):
    template = loader.get_template('index.html')
    return HttpResponse(template.render())

def add_dept(request):  
    if request.method == "POST":  
        form = DepartmentForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return HttpResponseRedirect('/studdbms/departments/')  
            except:  
                pass 
    else:  
        form = DepartmentForm()  
    return render(request,'dept_index.html',{'form':form})

def dept_index(request):  
    departments = Department.objects.all()  
    return render(request,"dept_show.html",{'departments':departments})

def dept_edit(request, dept_id):  
    department = Department.objects.get(dept_id=dept_id)  
    return render(request,'dept_edit.html', {'department':department})

def dept_update(request, dept_id):  
    department = Department.objects.get(dept_id=dept_id)  
    form = DepartmentForm(request.POST, instance = department)  
    if form.is_valid():  
        form.save()  
        return HttpResponseRedirect('/studdbms/departments/')  
    return render(request, 'dept_edit.html', {'department': department})

def dept_destroy(request, dept_id):  
    department = Department.objects.get(dept_id=dept_id)  
    department.delete()  
    return redirect('departments')


#Staff members view
def add_staff(request):  
    if request.method == "POST":  
        form = StaffForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return HttpResponseRedirect('/studdbms/staffs/')  
            except:  
                pass 
    else:  
        form = StaffForm()  
    return render(request,'staff_index.html',{'form':form})

def staff_index(request):  
    staffs = StaffDetails.objects.all()  
    return render(request,"staff_show.html",{'staffs':staffs})

def staff_edit(request, staff_id):  
    staff = StaffDetails.objects.get(staff_id=staff_id)  
    return render(request,'staff_edit.html', {'staff':staff})

def staff_update(request, staff_id):  
    staff = StaffDetails.objects.get(staff_id=staff_id)  
    form = StaffForm(request.POST, instance = staff)  
    if form.is_valid():  
        form.save()  
        return HttpResponseRedirect('/studdbms/staffs/')  
    return render(request, 'staff_edit.html', {'staff': staff})

def staff_destroy(request, staff_id):  
    staff = StaffDetails.objects.get(staff_id=staff_id)  
    staff.delete()  
    return redirect('staffs')

#Subject view
def add_subject(request):  
    if request.method == "POST":  
        form = SubjectForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return HttpResponseRedirect('/studdbms/subjects/')  
            except:  
                pass 
    else:  
        form = SubjectForm()  
    return render(request,'subject_index.html',{'form':form})

def subject_index(request):  
    subjects = Subjects.objects.all()  
    return render(request,"subject_show.html",{'subjects':subjects})

def subject_edit(request, sub_id):  
    subject = Subjects.objects.get(sub_id=sub_id)  
    return render(request,'subject_edit.html', {'subject':subject})

def subject_update(request, sub_id):  
    subject = Subjects.objects.get(sub_id=sub_id)  
    form = SubjectForm(request.POST, instance = subject)  
    if form.is_valid():  
        form.save()  
        return HttpResponseRedirect('/studdbms/subjects/')  
    return render(request, 'subject_edit.html', {'subject': subject})

def subject_destroy(request, sub_id):  
    subject = Subjects.objects.get(sub_id=sub_id)  
    subject.delete()  
    return redirect('subjects')

#Student view
def add_student(request):  
    if request.method == "POST":  
        form = StudentForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return HttpResponseRedirect('/studdbms/students/')  
            except:  
                pass 
    else:  
        form = StudentForm()  
    return render(request,'student_index.html',{'form':form})

def student_index(request):  
    students = Students.objects.all()  
    return render(request,"student_show.html",{'students':students})

def student_edit(request, stud_id):  
    student = Students.objects.get(stud_id=stud_id)  
    return render(request,'student_edit.html', {'student':student})

def student_update(request, stud_id):  
    student = Students.objects.get(stud_id=stud_id)  
    form = StudentForm(request.POST, instance = student) 
    if form.is_valid():  
        form.save()  
        return HttpResponseRedirect('/studdbms/students/')  
    return render(request, 'student_edit.html', {'student': student})

def student_destroy(request, stud_id):  
    student = Students.objects.get(stud_id=stud_id)  
    student.delete()  
    return redirect('students')

#Attendance view
def add_attend(request):  
    if request.method == "POST":  
        form = AttendForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return HttpResponseRedirect('/studdbms/attends/')  
            except:  
                pass 
    else:  
        form = AttendForm()  
    return render(request,'attend_index.html',{'form':form})

def attend_index(request):  
    attends = Attendence.objects.all()  
    return render(request,"attend_show.html",{'attends':attends})

def attend_edit(request, a_id):  
    attend = Attendence.objects.get(a_id=a_id)  
    return render(request,'attend_edit.html', {'attend':attend})

def attend_update(request, a_id):  
    attend = Attendence.objects.get(a_id=a_id)  
    form = AttendForm(request.POST, instance = attend) 
    if form.is_valid():  
        form.save()  
        return HttpResponseRedirect('/studdbms/attends/')  
    return render(request, 'attend_edit.html', {'attend': attend})

def attend_destroy(request, a_id):  
    attend = Attendence.objects.get(a_id=a_id)  
    attend.delete()  
    return redirect('attends')

#Parents View
def add_parent(request):  
    if request.method == "POST":  
        form = ParentForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return HttpResponseRedirect('/studdbms/parents/')  
            except:  
                pass 
    else:  
        form = ParentForm()  
    return render(request,'parent_index.html',{'form':form})

def parent_index(request):  
    parents = Parents.objects.all()  
    return render(request,"parent_show.html",{'parents':parents})

def parent_edit(request, p_id):  
    parent = Parents.objects.get(p_id=p_id)  
    return render(request,'parent_edit.html', {'parent':parent})

def parent_update(request, p_id):  
    parent = Parents.objects.get(p_id=p_id)  
    form = ParentForm(request.POST, instance = parent) 
    if form.is_valid():  
        form.save()  
        return HttpResponseRedirect('/studdbms/parents/')  
    return render(request, 'parent_edit.html', {'parent': parent})

def parent_destroy(request, p_id):  
    parent = Parents.objects.get(p_id=p_id)  
    parent.delete()  
    return redirect('parents')

# def subjects(request):
#     mysubjects = Subjects.objects.all().values()
#     template = loader.get_template('subjects.html')
#     context={
#         'mysubjects':mysubjects
#     }
#     return HttpResponse(template.render(context, request))

# def add_sub(request):                 #adding departments
#     if request.method == "POST":
#         scode = request.POST.get('scode')
#         sname = request.POST.get('sname')
#         sem = request.POST.get('sem')
#         dept = request.POST.get('dept')
#         sub = Subjects(scode=scode, sname=sname, sem=sem, dept=dept)
#         sub.save()
#         messages.info(request,"Subject added Successfully")
#         return redirect('subjects')
#     else:
#         pass
#     mysubjects = Subjects.objects.all().values()
#     context ={
#         'mysubjects': mysubjects
#     }
#     return render(request,'subjects.html',context)

# def edit_sub(request, sub_id):                 #editing department
#     mysubjects = Subjects.objects.get(sub_id=sub_id)
#     context = {
#         'mysubjects': mysubjects
#     }
#     return redirect(request,'subjects.html',context)

# def update_sub(request):                 #adding departments
#     if request.method == "POST":
#         scode = request.POST.get('scode')
#         sname = request.POST.get('sname')
#         sem = request.POST.get('sem')
#         dept = request.POST.get('dept')
#         sub = Subjects(scode=scode, sname=sname, sem=sem, dept=dept)
#         sub.save()
#         messages.info(request,"Subject update Successfully")
#         return redirect('subjects')
#     else:
#         pass
#     mysubjects = Subjects.objects.all().values()
#     context ={
#         'mysubjects': mysubjects
#     }
#     return render(request,'subjects.html',context)

# def destroy_sub(request, sub_id):  
#     mysubjects = Subjects.objects.get(sub_id=sub_id)
#     mysubjects.delete()  
#     return redirect('subjects')

# def departments(request):
#     mydepartment = Department.objects.all().values()
#     template = loader.get_template('departments.html')
#     context={
#         'mydepartment':mydepartment
#     }
#     return HttpResponse(template.render(context, request))

# def add_dept(request):                 #adding departments
#     if request.method == "POST":
#         dept_id = request.POST.get('dept_id')
#         dept_name = request.POST.get('dept_name')
#         dept = Department(dept_id=dept_id, dept_name=dept_name)
#         dept.save()
#         messages.info(request,"Department added Successfully")
#         return redirect('departments')
#     else:
#         pass
#     mydepartment = Department.objects.all().values()
#     context ={
#         'mydepartment': mydepartment
#     }
#     return render(request,'departments.html',context)

# def edit_dept(request, dept_id):                 #editing department
#     mydepartment = Department.objects.get(dept_id=dept_id)
#     context = {
#         'mydepartment': mydepartment
#     }
#     return redirect(request,'departments.html',context)

# def update_dept(request):                 #adding departments
#     if request.method == "POST":
#         dept_id = request.POST.get('dept_id')
#         dept_name = request.POST.get('dept_name')
#         dept = Department(dept_id=dept_id, dept_name=dept_name)
#         dept.save()
#         messages.info(request,"Department update Successfully")
#         return redirect('departments')
#     else:
#         pass
#     mydepartment = Department.objects.all().values()
#     context ={
#         'mydepartment': mydepartment
#     }
#     return render(request,'departments.html',context)

# def destroy_dept(request, dept_id):  
#     mydepartment = Department.objects.get(dept_id=dept_id)
#     mydepartment.delete()  
#     return HttpResponseRedirect('/studdbms/departments/')

# def staffdetails(request):
#     mystaff = StaffDetails.objects.all().values()
#     template = loader.get_template('staffdetails.html')
#     context={
#         'mystaff':mystaff
#     }
#     return HttpResponse(template.render(context, request))

# def add_staff(request):                 #adding departments
#     if request.method == "POST":
#         staff_id = request.POST.get('staff_id')
#         fn = request.POST.get('fn')
#         ln = request.POST.get('ln')
#         password = request.POST.get('password')
#         qualifications = request.POST.get('qualifications')
#         dept = request.POST.get('dept')
#         staff = StaffDetails(staff_id=staff_id, fn=fn, ln=ln, password=password, qualifications=qualifications, dept=dept)
#         staff.save()
#         messages.info(request,"Staff Added Successfully")
#         return redirect('staffdetails')
#     else:
#         pass
#     mystaff = StaffDetails.objects.all().values()
#     context ={
#         'mystaff': mystaff
#     }
#     return render(request,'staffdetails.html',context)

# def edit_staff(request, staff_id):                 #editing department
#     mystaff = StaffDetails.objects.get(staff_id=staff_id)
#     context = {
#         'mystaff': mystaff
#     }
#     return redirect(request,'staffdetails.html',context)

# def update_staff(request):                 #adding departments
#     if request.method == "POST":
#         staff_id = request.POST.get('staff_id')
#         fn = request.POST.get('fn')
#         ln = request.POST.get('ln')
#         password = request.POST.get('password')
#         qualifications = request.POST.get('qualifications')
#         dept = request.POST.get('dept')
#         staff = StaffDetails(staff_id=staff_id, fn=fn, ln=ln, password=password, qualifications=qualifications, dept=dept)
#         staff.save()
#         messages.info(request,"Staff Added Successfully")
#         return redirect('staffdetails')
#     else:
#         pass
#     mystaff = StaffDetails.objects.all().values()
#     context ={
#         'mystaff': mystaff
#     }
#     return render(request,'staffdetails.html',context)

# def destroy_staff(request, staff_id):  
#     mystaff = StaffDetails.objects.get(staff_id=staff_id)
#     mystaff.delete()  
#     return redirect('staffdetails')



# def students(request):
#     mystudents = Students.objects.all().values()
#     template = loader.get_template('students.html')
#     context={
#         'mystudents':mystudents
#     }
#     return HttpResponse(template.render(context, request))

# def add_stud(request):                 #adding departments
#     if request.method == "POST":
#         usn = request.POST.get('usn')
#         fn = request.POST.get('fn')
#         ln = request.POST.get('ln')
#         dept = request.POST.get('dept')
#         gender = request.POST.get('gender')
#         sem = request.POST.get('sem')
#         dob = request.POST.get('dob')
#         phone = request.POST.get('sem')
#         sec = request.POST.get('sec')
#         stud = Students(usn=usn, fn=fn, ln=ln, dept=dept, gender=gender, sem=sem, dob=dob, phone=phone, sec=sec)
#         stud.save()
#         messages.info(request,"Student added Successfully")
#         return redirect('students')
#     else:
#         pass
#     mystudent = Students.objects.all()
#     context ={
#         'mystudent': mystudent
#     }
#     return render(request,'students.html',context)

# def edit_stud(request, stud_id):                 #editing department
#     mystudent = Students.objects.get(stud_id=stud_id)
#     context = {
#         'mystudent': mystudent
#     }
#     return redirect(request,'students.html',context)

# def update_stud(request):                 #adding departments
#     if request.method == "POST":
#         usn = request.POST.get('usn')
#         fn = request.POST.get('fn')
#         ln = request.POST.get('ln')
#         dept = request.POST.get('dept')
#         gender = request.POST.get('gender')
#         sem = request.POST.get('sem')
#         dob = request.POST.get('dob')
#         phone = request.POST.get('sem')
#         sec = request.POST.get('sec')
#         stud = Students(usn=usn, fn=fn, ln=ln, dept=dept, gender=gender, sem=sem, dob=dob, phone=phone, sec=sec)
#         stud.save()
#         messages.info(request,"Student Updated Successfully")
#         return redirect('students')
#     else:
#         pass
#     mystudent = Students.objects.all()
#     context ={
#         'mystudent': mystudent
#     }
#     return render(request,'students.html',context)

# def destroy_stud(request, stud_id):  
#     mystudent = Students.objects.get(stud_id=stud_id)
#     mystudent.delete()  
#     return redirect('students')


# def parents(request):
#     myparents = Parents.objects.all()
#     template = loader.get_template('parents.html')
#     context={
#         'myparents':myparents
#     }
#     return HttpResponse(template.render(context, request))

# def add_parent(request):                 #adding departments
#     if request.method == "POST":
#         id_no = request.POST.get('id_no')
#         pname= request.POST.get('pname')
#         stud_usn = request.POST.get('stud_usn')
#         address = request.POST.get('address')
#         phone = request.POST.get('phone')
#         parent = Parents(id_no=id_no, pname=pname, stud_usn=stud_usn, address=address, phone=phone)
#         parent.save()
#         messages.info(request,"Parent Added Successfully")
#         return redirect('parents')
#     else:
#         pass
#     myparent = Parents.objects.all()
#     context ={
#         'myparent': myparent
#     }
#     return render(request,'parents.html',context)

# def edit_parent(request, parent_id):                 #editing department
#     myparent = Parents.objects.get(parent_id=parent_id)
#     context = {
#         'myparent': myparent
#     }
#     return redirect(request,'parents.html',context)

# def update_parent(request):                 #adding departments
#     if request.method == "POST":
#         id_no = request.POST.get('id_no')
#         pname= request.POST.get('pname')
#         stud_usn = request.POST.get('stud_usn')
#         address = request.POST.get('address')
#         phone = request.POST.get(' phone')
#         parent = Parents(id_no=id_no, pname=pname, stud_usn=stud_usn, address=address, phone=phone)
#         parent.save()
#         messages.info(request,"Parent Added Successfully")
#         return redirect('parents')
#     else:
#         pass
#     myparent = Parents.objects.all()
#     context ={
#         'myparent': myparent
#     }
#     return render(request,'parents.html',context)

# def destroy_parent(request, parent_id):  
#     myparent = Parents.objects.get(parent_id=parent_id)
#     myparent.delete()  
#     return redirect('parents')
