from django import forms  
from .models import *

class DepartmentForm(forms.ModelForm):  
    class Meta:  
        model = Department 
        fields = ['dept_id', 'dept_name'] #https://docs.djangoproject.com/en/3.0/ref/forms/widgets/
        widgets = { 'dept_id': forms.TextInput(attrs={ 'class': 'form-control' }), 
            'dept_name': forms.TextInput(attrs={ 'class': 'form-control' })
      }
        
class StaffForm(forms.ModelForm):  
    class Meta:  
        model = StaffDetails
        fields = ['staff_id', 'fn', 'ln','password', 'qualifications', 'dept' ] #https://docs.djangoproject.com/en/3.0/ref/forms/widgets/
        widgets = { 'staff_id': forms.TextInput(attrs={ 'class': 'form-control' }), 
            'fn': forms.TextInput(attrs={ 'class': 'form-control' }),
            'ln': forms.TextInput(attrs={ 'class': 'form-control' }),
            'password': forms.PasswordInput(attrs={ 'class': 'form-control' }),
            'qualifications': forms.TextInput(attrs={ 'class': 'form-control' }),
            'dept': forms.TextInput(attrs={ 'class': 'form-control' }),
      }
        
class SubjectForm(forms.ModelForm):  
    class Meta:  
        model = Subjects
        fields = ['sub_id','scode', 'sname', 'sem','dept'] #https://docs.djangoproject.com/en/3.0/ref/forms/widgets/
        widgets = {'sub_id': forms.TextInput(attrs={ 'class': 'form-control' }),
            'scode': forms.TextInput(attrs={ 'class': 'form-control' }), 
            'sname': forms.TextInput(attrs={ 'class': 'form-control' }),
            'sem': forms.TextInput(attrs={ 'class': 'form-control' }),
            'dept': forms.TextInput(attrs={ 'class': 'form-control' }),
      }

class StudentForm(forms.ModelForm):  
    class Meta:  
        model = Students
        fields = ['stud_id', 'usn', 'fn','ln', 'dept', 'gender','sem','dob','phone','sec' ] #https://docs.djangoproject.com/en/3.0/ref/forms/widgets/
        widgets = { 'stud_id': forms.TextInput(attrs={ 'class': 'form-control' }), 
            'usn': forms.TextInput(attrs={ 'class': 'form-control' }),
            'fn': forms.TextInput(attrs={ 'class': 'form-control' }),
            'ln': forms.TextInput(attrs={ 'class': 'form-control' }),
            'dept': forms.TextInput(attrs={ 'class': 'form-control' }),
            'gender': forms.TextInput(attrs={ 'class': 'form-control' }),
            'sem': forms.TextInput(attrs={ 'class': 'form-control' }),
            'dob': forms.DateInput(attrs={ 'class': 'form-control','placeholder':'yyyy-mm-dd' }),
            'phone': forms.TextInput(attrs={ 'class': 'form-control' }),
            'sec': forms.TextInput(attrs={ 'class': 'form-control' }),
      }
        
class ParentForm(forms.ModelForm):  
    class Meta:  
        model = Parents
        fields = ['p_id','pname', 'stud_usn', 'address','phone'] #https://docs.djangoproject.com/en/3.0/ref/forms/widgets/
        widgets = {'p_id': forms.TextInput(attrs={ 'class': 'form-control' }),
            'pname': forms.TextInput(attrs={ 'class': 'form-control' }), 
            'stud_usn': forms.TextInput(attrs={ 'class': 'form-control' }),
            'address': forms.TextInput(attrs={ 'class': 'form-control' }),
            'phone': forms.TextInput(attrs={ 'class': 'form-control' }),
      }
        
class AttendForm(forms.ModelForm):  
    class Meta:  
        model = Attendence
        fields = ['a_id', 'adate', 'period','usn', 'scode', 'status' ] #https://docs.djangoproject.com/en/3.0/ref/forms/widgets/
        widgets = { 'a_id': forms.TextInput(attrs={ 'class': 'form-control' }), 
            'adate': forms.DateInput(attrs={ 'class': 'form-control', 'placeholder':'yyyy-mm-dd' }),
            'period': forms.TextInput(attrs={ 'class': 'form-control', 'placeholder':'h-m-s' }),
            'usn': forms.TextInput(attrs={ 'class': 'form-control' }),
            'scode': forms.TextInput(attrs={ 'class': 'form-control' }),
            'status': forms.TextInput(attrs={ 'class': 'form-control' }),
      }
