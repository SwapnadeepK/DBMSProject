from django.contrib import admin
from . models import *
# Register your models here.
admin.site.register(Students)
admin.site.register(Parents)
admin.site.register(Department)
admin.site.register(StaffDetails)
admin.site.register(Subjects)
admin.site.register(Timings)
admin.site.register(Attendence)
