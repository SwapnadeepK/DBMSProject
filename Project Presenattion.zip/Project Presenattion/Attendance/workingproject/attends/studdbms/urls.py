from django.urls import path
from . import views
from django.contrib import admin
from django.urls.conf import include

urlpatterns = [
    path('',views.index, name='index'),

    path('departments/',views.dept_index, name='departments'),
    path('add_dept/',views.add_dept,name='add_dept'),
    path('dept_edit/<str:dept_id>',views.dept_edit, name='dept_edit'),
    path('dept_update/<str:dept_id>', views.dept_update, name='dept_update'),
    path('dept_delete/<str:dept_id>',views.dept_destroy, name='dept_destroy'),
    
    path('staffs/',views.staff_index, name='staffs'),
    path('add_staff/',views.add_staff,name='add_staff'),
    path('staff_edit/<str:staff_id>',views.staff_edit, name='staff_edit'),
    path('staff_update/<str:staff_id>', views.staff_update, name='staff_update'),
    path('staff_delete/<str:staff_id>',views.staff_destroy, name='staff_destroy'),

    path('subjects/',views.subject_index, name='subjects'),
    path('add_subject/',views.add_subject,name='add_subject'),
    path('subject_edit/<str:sub_id>',views.subject_edit, name='subject_edit'),
    path('subject_update/<str:sub_id>', views.subject_update, name='subject_update'),
    path('subject_delete/<str:sub_id>',views.subject_destroy, name='subject_destroy'),

    path('students/',views.student_index, name='students'),
    path('add_student/',views.add_student,name='add_student'),
    path('student_edit/<str:stud_id>',views.student_edit, name='student_edit'),
    path('student_update/<str:stud_id>', views.student_update, name='student_update'),
    path('student_delete/<str:stud_id>',views.student_destroy, name='student_destroy'),

    path('parents/',views.parent_index, name='parents'),
    path('add_parent/',views.add_parent,name='add_parent'),
    path('parent_edit/<str:p_id>',views.parent_edit, name='parent_edit'),
    path('parent_update/<str:p_id>', views.parent_update, name='parent_update'),
    path('parent_delete/<str:p_id>',views.parent_destroy, name='parent_destroy'),

    path('attends/',views.attend_index, name='attends'),
    path('add_attend/',views.add_attend,name='add_attend'),
    path('attend_edit/<str:a_id>',views.attend_edit, name='attend_edit'),
    path('attend_update/<str:a_id>', views.attend_update, name='attend_update'),
    path('attend_delete/<str:a_id>',views.attend_destroy, name='attend_destroy'),


]
